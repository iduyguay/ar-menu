/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import '@google/model-viewer';
import { Bell, RotateCcw, RotateCw } from 'lucide-react';

// Extend JSX namespace for model-viewer
declare global {
  namespace React {
    namespace JSX {
      interface IntrinsicElements {
        'model-viewer': any;
      }
    }
  }
}

export default function App() {
  const [size, setSize] = useState(30);
  const modelRef = useRef<any>(null);

  const handleRotate = () => {
    if (modelRef.current) {
      modelRef.current.cameraOrbit = `${(parseFloat(modelRef.current.getCameraOrbit().theta) + Math.PI / 4)}rad ${modelRef.current.getCameraOrbit().phi}rad auto`;
    }
  };

  const handleReset = () => {
    if (modelRef.current) {
      modelRef.current.cameraOrbit = '0deg 75deg auto';
      modelRef.current.cameraTarget = '0m 0m 0m';
    }
  };

  return (
    <div className="flex flex-col h-screen bg-black text-white font-sans overflow-hidden">
      {/* 3D Area */}
      <div className="relative h-1/2 w-full bg-[#1a1a1a]">
        <model-viewer
          ref={modelRef}
          src="/pizza.glb" // Replace with your actual 3D model path
          ios-src=""
          alt="3D Pizza Model"
          auto-rotate
          camera-controls
          ar
          ar-modes="webxr scene-viewer quick-look"
          shadow-intensity="1"
          environment-image="neutral"
          exposure="1"
          className="w-full h-full"
        >
          <button
            slot="ar-button"
            className="absolute top-4 right-4 bg-orange-500 text-white px-4 py-2 rounded-full text-xs font-bold tracking-widest shadow-lg hover:bg-orange-600 transition-colors"
          >
            AR CANLI
          </button>
        </model-viewer>
        
        {/* Image fallback as requested */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
           <img 
            src="/pizza.png" // Replace with your actual pizza image path
            alt="Pizza Margherita" 
            className="w-full h-full object-cover opacity-50" // Semi-transparent to show 3D viewer if it loads
            referrerPolicy="no-referrer"
          />
        </div>
      </div>

      {/* Content Panel */}
      <div className="flex-1 bg-[#0a0a0a] p-6 flex flex-col justify-between relative">
        <div className="space-y-4">
          {/* Category */}
          <p className="text-orange-500 text-[10px] font-bold tracking-[0.2em] uppercase">
            PİZZA • KLASİK NAPOLİ
          </p>

          {/* Title & Subtitle */}
          <div className="space-y-1">
            <h1 className="text-5xl font-serif font-light tracking-tight">
              Margherita
            </h1>
            <p className="text-gray-400 italic text-lg font-serif">
              Classica
            </p>
          </div>

          {/* Price & Details */}
          <p className="text-[#f1c40f] font-medium text-sm tracking-wide">
            ₺280 • ∅ {size}cm • 8 Dilim
          </p>

          {/* Ingredients */}
          <div className="flex flex-wrap gap-2 pt-2">
            {[
              { name: 'San Marzano', emoji: '🍅' },
              { name: 'Mozzarella', emoji: '🧀' },
              { name: 'Fesleğen', emoji: '🌿' },
              { name: 'Zeytinyağı', emoji: '🫒' }
            ].map((ing) => (
              <span 
                key={ing.name}
                className="bg-[#1a1a1a] border border-white/10 px-3 py-1.5 rounded-md text-xs flex items-center gap-2 text-gray-300"
              >
                {ing.name} {ing.emoji}
              </span>
            ))}
          </div>

          {/* Size Selection */}
          <div className="flex items-center gap-4 pt-4">
            <span className="text-[10px] font-bold tracking-widest text-gray-500 uppercase">BOYUT</span>
            <input 
              type="range" 
              min="20" 
              max="40" 
              value={size}
              onChange={(e) => setSize(parseInt(e.target.value))}
              className="flex-1 accent-orange-500 h-1 bg-gray-800 rounded-lg appearance-none cursor-pointer"
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="glass absolute bottom-0 left-0 right-0 p-6 flex items-center justify-between gap-4">
          <div className="flex gap-2">
            <button 
              onClick={handleRotate}
              className="bg-[#1a1a1a] p-3 rounded-xl border border-white/5 hover:bg-[#252525] transition-colors group"
              title="Döndür"
            >
              <RotateCw size={20} className="text-gray-400 group-hover:text-white" />
            </button>
            <button 
              onClick={handleReset}
              className="bg-[#1a1a1a] p-3 rounded-xl border border-white/5 hover:bg-[#252525] transition-colors group"
              title="Sıfırla"
            >
              <RotateCcw size={20} className="text-gray-400 group-hover:text-white" />
            </button>
          </div>

          <button className="flex-1 bg-gradient-to-r from-orange-600 to-red-600 text-white py-3.5 px-6 rounded-xl font-bold flex items-center justify-center gap-3 shadow-lg shadow-orange-900/20 hover:scale-[1.02] active:scale-[0.98] transition-all">
            <Bell size={18} />
            Sipariş Ver
          </button>
        </div>
      </div>
    </div>
  );
}
